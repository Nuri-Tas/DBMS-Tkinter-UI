DROP TABLE Database_Managers;

DROP TABLE bought_tickets;

DROP TABLE screens_as;

DROP TABLE movie_sessions;

DROP TABLE theatre;

DROP TABLE average_ratings;

DROP TABLE ratings;

DROP TABLE has_genre;

DROP TABLE genre_list;

DROP TABLE predecessors;

DROP TABLE movie;

DROP TABLE director;

DROP TABLE subscribed_platforms;

DROP TABLE rating_platform;

DROP TABLE audience;

DROP TABLE users;
-- line of reasoning was to drop the tables that have foreign key relations first and the original keys last


    